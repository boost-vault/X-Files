/*=============================================================================
    Copyright (c) 2007 Tobias Schwinger
  
    Use modification and distribution are subject to the Boost Software 
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
==============================================================================*/

#ifndef BOOST_UTILITY_VALUE_FACTORY_HPP_INCLUDED
#   ifndef BOOST_PP_IS_ITERATING

#     include <boost/preprocessor/iteration/iterate.hpp>
#     include <boost/preprocessor/repetition/enum_params.hpp>
#     include <boost/preprocessor/repetition/enum_binary_params.hpp>

#     include <boost/type_traits/remove_cv.hpp>

#     ifndef BOOST_UTILITY_VALUE_FACTORY_MAX_ARITY
#       define BOOST_UTILITY_VALUE_FACTORY_MAX_ARITY 10
#     elif BOOST_UTILITY_VALUE_FACTORY_MAX_ARITY < 3
#       undef  BOOST_UTILITY_VALUE_FACTORY_MAX_ARITY
#       define BOOST_UTILITY_VALUE_FACTORY_MAX_ARITY 3
#     endif

namespace boost 
{ 
    template< typename T >
    struct value_factory
    {
        typedef T result_type;

        inline T operator()() const
        {
            typedef typename boost::remove_cv<T>::type value_type;
            return value_type();
        }

#     define BOOST_PP_FILENAME_1 <boost/functional/value_factory.hpp>
#     define BOOST_PP_ITERATION_LIMITS (1,BOOST_UTILITY_VALUE_FACTORY_MAX_ARITY)
#     include BOOST_PP_ITERATE()
    };

    template< typename T >
    struct value_factory<T &>;
    // forbidden, would create a dangling reference
}

#     define BOOST_UTILITY_VALUE_FACTORY_HPP_INCLUDED
#   else // defined(BOOST_PP_IS_ITERATING)
#     define N BOOST_PP_ITERATION()
        template< BOOST_PP_ENUM_PARAMS(N, typename T) >
        inline T operator()(BOOST_PP_ENUM_BINARY_PARAMS(N,T,& a)) const
        {
            return T(BOOST_PP_ENUM_PARAMS(N, a));
        }        
#     undef N
#   endif // defined(BOOST_PP_IS_ITERATING)

#endif // include guard

