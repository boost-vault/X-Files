/*=============================================================================
    Copyright (c) 2007 Tobias Schwinger
  
    Use modification and distribution are subject to the Boost Software 
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
==============================================================================*/

#ifndef BOOST_FUNCTIONAL_FORWARD_ADAPTER_HPP_INCLUDED
#   ifndef BOOST_PP_IS_ITERATING

#   include <boost/config.hpp>
#   include <boost/detail/workaround.hpp>

#   include <boost/preprocessor/iteration/iterate.hpp>
#   include <boost/preprocessor/repetition/enum_params.hpp>
#   include <boost/preprocessor/repetition/enum_binary_params.hpp>
#   include <boost/preprocessor/facilities/intercept.hpp>

#   include <boost/call_traits.hpp>
#   include <boost/utility/result_of.hpp>

#     ifndef BOOST_FUNCTIONAL_FORWARD_ADAPTER_MAX_ARITY
#       define BOOST_FUNCTIONAL_FORWARD_ADAPTER_MAX_ARITY 5
#     elif BOOST_FUNCTIONAL_FORDWARD_ADAPTER_MAX_ARITY < 3
#       undef  BOOST_FUNCTIONAL_FORWARD_ADAPTER_MAX_ARITY
#       define BOOST_FUNCTIONAL_FORWARD_ADAPTER_MAX_ARITY 3
#     endif


namespace boost 
{
    template< class Function > class forward_adapter;

    //----- ---- --- -- - -  -   -

    template< class Function > 
    class forward_adapter
    {
        Function fnc_adaptee;

        typedef forward_adapter<Function> self;

        template< typename T > struct qf_c          { typedef T const  type; };
        template< typename T > struct qf_c<T const> { typedef T const  type; };
        template< typename T > struct qf_c<T &>     { typedef T        type; };

        template< typename T > struct qf            { typedef T        type; };
        template< typename T > struct qf<T const>   { typedef T const  type; };
        template< typename T > struct qf<T &>       { typedef T        type; };

        typedef typename self::template qf_c<Function>::type function_c;
        typedef typename self::template qf<Function>::type function;

        typedef typename boost::call_traits<Function>::param_type func_param_t;

        template< typename T > struct gref          { typedef T const& type; };
        template< typename T > struct gref<T&>      { typedef T      & type; };
        template< typename T > struct gref<T const> { typedef T const& type; };

      public:

        inline explicit forward_adapter(func_param_t f = Function())
            : fnc_adaptee(f)
        { }

        template< typename Sig >
        struct result;

        typedef typename boost::result_of<
            function_c() >::type call_const_0_result;

        inline call_const_0_result operator()() const
        {
            return this->fnc_adaptee();
        }

        typedef typename boost::result_of< function () >::type call_0_result;

        inline call_0_result operator()() 
        {
            return this->fnc_adaptee();
        }

        #define BOOST_TMP_MACRO(tpl_params,arg_types,params,args)             \
        template< tpl_params >                                                 \
        inline typename boost::result_of<function_c(arg_types)>::type          \
        operator()(params) const                                               \
        {                                                                      \
            return this->fnc_adaptee(args);                                    \
        }                                                                      \
        template< tpl_params >                                                 \
        inline typename boost::result_of<function(arg_types)>::type            \
        operator()(params)                                                     \
        {                                                                      \
            return this->fnc_adaptee(args);                                    \
        }

        #define  BOOST_PP_INDIRECT_SELF <boost/functional/forward_adapter.hpp>
        #define  BOOST_PP_FILENAME_1                                           \
            <boost/functional/detail/fwd_adapter_explode.hpp>
        #define  BOOST_PP_ITERATION_LIMITS                                     \
            (1,BOOST_FUNCTIONAL_FORWARD_ADAPTER_MAX_ARITY)
        #define  N BOOST_PP_ITERATION_1
        #include BOOST_PP_ITERATE()
        #undef   N

        #undef BOOST_TMP_MACRO
    };
}

namespace boost 
{
    template<class F>
    struct result_of<boost::forward_adapter<F> const ()>
    {
        typedef typename boost::forward_adapter<F>::call_const_0_result type;
    };
    template<class F>
    struct result_of<boost::forward_adapter<F>()>
    {
        typedef typename boost::forward_adapter<F>::call_0_result type;
    };
}

#     define BOOST_FUNCTIONAL_FORWARD_ADAPTER_HPP_INCLUDED

#   else // defined(BOOST_PP_IS_ITERATING)

#     if BOOST_PP_SLOT_1() & 0x001
#       define PT0 T0 &
#     else
#       define PT0 T0 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x002
#       define PT1 T1 &
#     else
#       define PT1 T1 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x004
#       define PT2 T2 &
#     else
#       define PT2 T2 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x008
#       define PT3 T3 &
#     else
#       define PT3 T3 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x010
#       define PT4 T4 &
#     else
#       define PT4 T4 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x020
#       define PT5 T5 &
#     else
#       define PT5 T5 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x040
#       define PT6 T6 &
#     else
#       define PT6 T6 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x080
#       define PT7 T7 &
#     else
#       define PT7 T7 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x100
#       define PT8 T8 &
#     else
#       define PT8 T8 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x200
#       define PT9 T9 &
#     else
#       define PT9 T9 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x400
#       define PT10 T10 &
#     else
#       define PT10 T10 const &
#     endif
#     if BOOST_PP_SLOT_1() & 0x800
#       define PT11 T11 &
#     else
#       define PT11 T11 const &
#     endif

#     if BOOST_PP_SLOT_1() == 0 
        template< class Self, BOOST_PP_ENUM_PARAMS(N,typename T) >
        struct result< Self const (BOOST_PP_ENUM_PARAMS(N,T)) >
            : boost::result_of<function_c(
                BOOST_PP_ENUM_BINARY_PARAMS(N,
                   typename self::template gref<T,>::type BOOST_PP_INTERCEPT)) >
        { };

        template< class Self, BOOST_PP_ENUM_PARAMS(N,typename T) >
        struct result< Self(BOOST_PP_ENUM_PARAMS(N,T)) >
            : boost::result_of<function (
                BOOST_PP_ENUM_BINARY_PARAMS(N,
                   typename self::template gref<T,>::type BOOST_PP_INTERCEPT)) >
        { };
#     endif

#     if BOOST_WORKAROUND(BOOST_MSVC,BOOST_TESTED_AT(1400)) 
        template< BOOST_PP_ENUM_PARAMS(N,typename T) >
        inline typename boost::result_of<function_c(
            BOOST_PP_ENUM_PARAMS(N,PT)) >::type
        operator()(BOOST_PP_ENUM_BINARY_PARAMS(N,PT,a)) const
        {
            return this->fnc_adaptee(BOOST_PP_ENUM_PARAMS(N,a));
        }
        template< BOOST_PP_ENUM_PARAMS(N,typename T) >
        inline typename boost::result_of<function(
            BOOST_PP_ENUM_PARAMS(N,PT)) >::type
        operator()(BOOST_PP_ENUM_BINARY_PARAMS(N,PT,a))
        {
            return this->fnc_adaptee(BOOST_PP_ENUM_PARAMS(N,a));
        }
#     else
        BOOST_TMP_MACRO(BOOST_PP_ENUM_PARAMS(N,typename T),
            BOOST_PP_ENUM_PARAMS(N,PT), BOOST_PP_ENUM_BINARY_PARAMS(N,PT,a),
            BOOST_PP_ENUM_PARAMS(N,a) )
        // ...generates uglier code but is faster - it caches ENUM_*
#     endif

#     undef PT0
#     undef PT1
#     undef PT2
#     undef PT3
#     undef PT4
#     undef PT5
#     undef PT6
#     undef PT7
#     undef PT8
#     undef PT9
#     undef PT10
#     undef PT11
#   endif // defined(BOOST_PP_IS_ITERATING)

#endif // include guard

